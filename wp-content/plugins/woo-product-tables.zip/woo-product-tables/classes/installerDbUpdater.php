<?php
class InstallerDbUpdaterWtbp {
	public static function runUpdate() {

	}
}
