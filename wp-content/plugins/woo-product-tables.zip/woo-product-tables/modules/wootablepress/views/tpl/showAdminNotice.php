<div class="error notice">
	<p><?php HtmlWtbp::echoEscapedHtml($this->errorMsg); ?></p>
</div>
