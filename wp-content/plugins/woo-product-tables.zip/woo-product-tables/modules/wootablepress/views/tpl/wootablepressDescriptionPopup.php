<div id="wtbpModal" class="wtbpModal" style="display: none;">
	<div class="wtbpModalContent">
		<span class="wtbpCloseModal">×</span>
		<div class="wtbpModalContentPlaceholder"></div>
	</div>
</div>