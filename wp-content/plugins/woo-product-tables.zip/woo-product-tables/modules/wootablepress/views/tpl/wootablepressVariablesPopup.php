<div id="wtbpVariablesModal" class="wtbpModal" style="display: none;">
	<div class="wtbpModalContent wtbpModalContentForVariations">
		<span class="wtbpCloseModal">×</span>
		<div class="wtbpModalContentPlaceholder">
			<div class="wtbpModalVariationImages"></div>
			<div class="wtbpModalVariationName"></div>
			<div class="wtbpModalVariationDescription"></div>
			<div class="wtbpModalVariationAttributes"></div>
			<div class="wtbpModalVariationBtns" data-add-to-cart-text="<?php esc_attr_e(__('Add for ', 'woo-product-tables')); ?>"></div>
		</div>
	</div>
</div>
