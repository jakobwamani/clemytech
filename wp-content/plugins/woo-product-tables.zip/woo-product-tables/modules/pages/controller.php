<?php
class PagesControllerWtbp extends ControllerWtbp {

}

