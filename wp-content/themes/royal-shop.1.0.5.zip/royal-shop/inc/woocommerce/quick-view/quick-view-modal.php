<?php
/**
 * WooCommerce - Quick View Modal
 *
 * @package royalshop
 */

?>
<div class="alm-quick-view-bg"><div class="alm-quick-view-loader blockOverlay">

</div></div>
<div id="alm-quick-view-modal">
	<div class="alm-content-main-wrapper"><?php ;/*Don't remove this html comment*/ ?><!--
	--><div class="alm-content-main">
			<div class="alm-lightbox-content">
				<div class="alm-content-main-head">
					<a href="#" id="alm-quick-view-close" class="alm-quick-view-close-btn"></a>
				</div>
				<div id="alm-quick-view-content" class="woocommerce single-product"></div>
			</div>
		</div>
	</div>
</div>