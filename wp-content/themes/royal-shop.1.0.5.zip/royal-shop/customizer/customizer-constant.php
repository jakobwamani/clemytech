<?php
define('ROYAL_SHOP_TOP_HEADER_LAYOUT_1', ROYAL_SHOP_THEME_URI. "customizer/images/top-header-1.png");
define('ROYAL_SHOP_TOP_HEADER_LAYOUT_2', ROYAL_SHOP_THEME_URI. "customizer/images/top-header-2.png");
define('ROYAL_SHOP_TOP_HEADER_LAYOUT_3', ROYAL_SHOP_THEME_URI. "customizer/images/top-header-3.png");
define('ROYAL_SHOP_TOP_HEADER_LAYOUT_NONE', ROYAL_SHOP_THEME_URI. "customizer/images/top-header-none.png");

define('ROYAL_SHOP_MAIN_HEADER_LAYOUT_ONE', ROYAL_SHOP_THEME_URI. "customizer/images/main-header1.png");
define('ROYAL_SHOP_MAIN_HEADER_LAYOUT_TWO', ROYAL_SHOP_THEME_URI. "customizer/images/main-header2.png");
define('ROYAL_SHOP_MAIN_HEADER_LAYOUT_THREE', ROYAL_SHOP_THEME_URI. "customizer/images/main-header3.png");
define('ROYAL_SHOP_MAIN_HEADER_LAYOUT_FOUR', ROYAL_SHOP_THEME_URI. "customizer/images/main-header4.png");

define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_1', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-1.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_2', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-2.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_3', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-3.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_4', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-4.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_5', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-5.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_6', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-6.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_7', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-7.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_8', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-8.png");
define('ROYAL_SHOP_FOOTER_WIDGET_LAYOUT_NONE', ROYAL_SHOP_THEME_URI. "customizer/images/widget-footer-none.png");
//SLIDER
define('ROYAL_SHOP_SLIDER_LAYOUT_2', ROYAL_SHOP_THEME_URI. "customizer/images/slider-layout-2.png");
define('ROYAL_SHOP_SLIDER_LAYOUT_3', ROYAL_SHOP_THEME_URI. "customizer/images/slider-layout-3.png");
define('ROYAL_SHOP_SLIDER_LAYOUT_4', ROYAL_SHOP_THEME_URI. "customizer/images/slider-layout-4.png");
define('ROYAL_SHOP_SLIDER_LAYOUT_5', ROYAL_SHOP_THEME_URI. "customizer/images/slider-layout-5.png");
define('ROYAL_SHOP_SLIDER_LAYOUT_6', ROYAL_SHOP_THEME_URI. "customizer/images/slider-layout-6.png");
//category slider
define('ROYAL_SHOP_CAT_SLIDER_LAYOUT_1', ROYAL_SHOP_THEME_URI. "customizer/images/category-slider-1.png");
define('ROYAL_SHOP_CAT_SLIDER_LAYOUT_2', ROYAL_SHOP_THEME_URI. "customizer/images/category-slider-2.png");
define('ROYAL_SHOP_CAT_SLIDER_LAYOUT_3', ROYAL_SHOP_THEME_URI. "customizer/images/category-slider-3.png");
//Banner Slider
define('ROYAL_SHOP_BANNER_IMG_LAYOUT_1', ROYAL_SHOP_THEME_URI. "customizer/images/banner-image-1.png");
define('ROYAL_SHOP_BANNER_IMG_LAYOUT_2', ROYAL_SHOP_THEME_URI. "customizer/images/banner-image-2.png");
define('ROYAL_SHOP_BANNER_IMG_LAYOUT_3', ROYAL_SHOP_THEME_URI. "customizer/images/banner-image-3.png");
define('ROYAL_SHOP_BANNER_IMG_LAYOUT_4', ROYAL_SHOP_THEME_URI. "customizer/images/banner-image-4.png");
define('ROYAL_SHOP_BANNER_IMG_LAYOUT_5', ROYAL_SHOP_THEME_URI. "customizer/images/banner-image-5.png");
define('ROYAL_SHOP_BANNER_IMG_LAYOUT_6', ROYAL_SHOP_THEME_URI. "customizer/images/banner-image-6.png");